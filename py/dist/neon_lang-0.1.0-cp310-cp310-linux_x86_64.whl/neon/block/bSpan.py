import copy
import ctypes
from enum import Enum
import warp as wp
import neon
from neon import DataView


class bSpan(ctypes.Structure):
    _fields_ = [
        ("mFirstDataBlockOffset", ctypes.c_uint32),
        ("mActiveMask", ctypes.POINTER(ctypes.c_uint32)),
        ("mDataView", DataView)
    ]

    def __init__(self):
        self.handle: ctypes.c_void_p = ctypes.c_void_p(0)
        self.neon: neon.Gate = neon.Gate()
        self._help_load_api()

    def _help_load_api(self):
        pass
        # self.neon.lib.bGrid_bSpan_get_member_field_offsets.argtypes = [ctypes.POINTER(ctypes.c_size_t), ctypes.POINTER(ctypes.c_size_t)]
        # self.neon.lib.bGrid_bSpan_get_member_field_offsets.restype = None

    # def get_cpp_field_offsets(self):
    #     length = ctypes.c_size_t()
    #     offsets = (ctypes.c_size_t * 3)()  # Assuming there are 3 offsets
    #     self.neon.lib.bGrid_bSpan_get_member_field_offsets(offsets, ctypes.byref(length))
    #     return [offsets[i] for i in range(length.value)]


    def __str__(self):
        str_repr = f"<bSpan: addr={ctypes.addressof(self):#x}>"
        str_repr += f"\n\tmFirstDataBlockOffset: {self.mFirstDataBlockOffset} (offset: {bSpan.mFirstDataBlockOffset.offset})"
        str_repr += f"\n\tmActiveMask: {self.mActiveMask} (offset: {bSpan.mActiveMask.offset})"
        str_repr += f"\n\tmDataView: {self.mDataView} (offset: {bSpan.mDataView.offset})"
        return str_repr
    
    # def get_offsets(self):
    #     return [bSpan.mFirstDataBlockOffset.offset, bSpan.mActiveMask.offset, bSpan.mDataView.offset]

    @staticmethod
    def fields_():
        return bSpan._fields_

    @staticmethod
    def register_builtins():
        # register type
        wp.types.add_type(bSpan, native_name="NeonBlockSpan", has_binary_ctor=True)
        wp.context.add_builtin(
            "neon_set",
            input_types={"span": neon.block.bSpan, "is_valid": wp.bool},
            value_type=neon.block.bIndex,
            missing_grad=True,
        )