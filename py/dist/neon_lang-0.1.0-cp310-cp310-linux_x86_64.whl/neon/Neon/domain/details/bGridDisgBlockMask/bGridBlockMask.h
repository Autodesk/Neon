#pragma once
#include "Neon/core/core.h"

#include "Neon/domain/aGrid.h"
#include "Neon/domain/details/StaticBlock.h"
#include "Neon/domain/details/bGridDisgBlockMask/BlockView.h"
#include "Neon/domain/details/bGridDisgBlockMask/bMaskField.h"
#include "Neon/domain/details/bGridDisgBlockMask/bMaskIndex.h"
#include "Neon/domain/details/bGridDisgBlockMask/bMaskPartition.h"
#include "Neon/domain/details/bGridDisgBlockMask/bMaskSpan.h"
#include "Neon/domain/interface/GridBaseTemplate.h"
#include "Neon/domain/patterns/PatternScalar.h"
#include "Neon/domain/tools/Partitioner1D.h"
#include "Neon/domain/tools/PointHashTable.h"
#include "Neon/domain/tools/SpanTable.h"
#include "Neon/set/Containter.h"
#include "Neon/set/LaunchParametersTable.h"
#include "Neon/set/memory/memSet.h"

#include "Neon/domain/details/bGridDisgBlockMask/ClassificationGrid/cGrid.h"

#include "ClassificationGrid/cGrid.h"
#include "bMaskField.h"
#include "bMaskPartition.h"
#include "bMaskSpan.h"

namespace Neon::domain::details::disaggregated::bGridBlockMask {


template <typename T, int C, typename SBlock>
class bMaskField;

template <typename SBlock>
class bGridBlockMask : public Neon::domain::interface::GridBaseTemplate<bGridBlockMask<SBlock>,
                                                                        bMaskIndex<SBlock>>
{
   public:
    constexpr static bool alphaBetaCapabilitySupported = true;

    using Grid = bGridBlockMask<SBlock>;
    template <typename T, int C = 0>
    using Partition = bMaskPartition<T, C, SBlock>;
    template <typename T, int C = 0>
    using Field = Neon::domain::details::disaggregated::bGridBlockMask::bMaskField<T, C, SBlock>;

    using Span = bMaskSpan<SBlock>;
    using NghIdx = typename Partition<int>::NghIdx;
    using GridBaseTemplate = Neon::domain::interface::GridBaseTemplate<Grid, bMaskIndex<SBlock>>;

    using Idx = bMaskIndex<SBlock>;
    static constexpr Neon::set::details::ExecutionThreadSpan executionThreadSpan = Neon::set::details::ExecutionThreadSpan::d1b3;
    using ExecutionThreadSpanIndexType = uint32_t;

    using BlockIdx = uint32_t;

    template <typename SBlock_, int classSelector_>
    using cGrid = typename Neon::domain::details::disaggregated::bGridBlockMask::details::cGrid::cGrid<SBlock_, classSelector_>;
    using AlphaGrid = cGrid<SBlock, 1>;
    using BetaGrid = cGrid<SBlock, 2>;

    bGridBlockMask() = default;

    virtual ~bGridBlockMask();

    /**
     * Constructor for the vanilla block data structure with depth of 1
     */
    template <typename ActiveCellLambda>
    bGridBlockMask(const Neon::Backend&                         backend,
                   const Neon::int32_3d&                        domainSize,
                   const ActiveCellLambda                       activeCellLambda,
                   const Neon::domain::Stencil&                 stencil,
                   const double_3d&                             spacingData = double_3d(1, 1, 1),
                   const double_3d&                             origin = double_3d(0, 0, 0),
                   Neon::domain::tool::spaceCurves::EncoderType encoderType = Neon::domain::tool::spaceCurves::EncoderType::sweep);


    /**
     * Constructor for bGrid. This constructor should be directly used only by mGrid
     */
    template <typename ActiveCellLambda>
    bGridBlockMask(const Neon::Backend&         backend /**< Neon backend for the computation */,
                   const Neon::int32_3d&        domainSize /**< Size of the bounded Cartesian */,
                   const ActiveCellLambda       activeCellLambda /**< Function that identify the user domain inside the boxed Cartesian discretization  */,
                   const Neon::domain::Stencil& stencil /**< union of tall the stencil that will be used in the computation */,
                   const int                    multiResDiscreteIdxSpacing /**< Parameter for the multi-resolution. Index i and index (i+1) may be remapped as i*voxelSpacing  and (i+1)* voxelSpacing.
                                                                            * For a uniform bGrid, i.e outside the context of multi-resolution this parameter is always 1 */
                   ,
                   const double_3d&                             spacingData /** Physical spacing between two consecutive data points in the Cartesian domain */,
                   const double_3d&                             origin /** Physical location in space of the origin of the Cartesian discretization */,
                   Neon::domain::tool::spaceCurves::EncoderType encoderType = Neon::domain::tool::spaceCurves::EncoderType::sweep);

    /**
     * Returns some properties for a given cartesian in the Cartesian domain.
     * The provide index my be inside or outside the user defined bounded Cartesian domain
     */
    auto getProperties(const Neon::index_3d& idx)
        const -> typename GridBaseTemplate::CellProperties final;

    /**
     * Returns true if the query 3D point is inside the user domain
     * @param idx
     * @return
     */
    auto isInsideDomain(const Neon::index_3d& idx)
        const -> bool final;

    /**
     * Retrieves the device index that contains the query point
     * @param idx
     * @return
     */
    auto getSetIdx(const Neon::index_3d& idx)
        const -> int32_t final;

    /**
     * Allocates a new field on the grid
     */
    template <typename T, int C = 0>
    auto newField(const std::string   name,
                  int                 cardinality,
                  T                   inactiveValue,
                  Neon::DataUse       dataUse = Neon::DataUse::HOST_DEVICE,
                  Neon::MemoryOptions memoryOptions = Neon::MemoryOptions()) const
        -> Field<T, C>;

    /**
     * Allocates a new field on the block view grid
     */
    template <typename T, int C = 0>
    auto newBlockViewField(const std::string   name,
                           int                 cardinality,
                           T                   inactiveValue,
                           Neon::DataUse       dataUse = Neon::DataUse::HOST_DEVICE,
                           Neon::MemoryOptions memoryOptions = Neon::MemoryOptions()) const
        -> BlockView::Field<T, C>;

    /**
     * Allocates a new container to execute some computation in the grid
     */
    template <Neon::Execution execution = Neon::Execution::device,
              typename LoadingLambda = void*>
    auto newContainer(const std::string& name,
                      index_3d           blockSize,
                      size_t             sharedMem,
                      LoadingLambda      lambda) const -> Neon::set::Container;

    /**
     * Allocates a new container to execute some computation in the grid
     */
    template <Neon::Execution execution = Neon::Execution::device,
              typename LoadingLambda = void*>
    auto newContainer(const std::string& name,
                      LoadingLambda      lambda) const -> Neon::set::Container;

    template <Neon::Execution execution = Neon::Execution::device,
              typename LoadingLambda = void*>
    auto newAlphaContainer(const std::string& name,
                           LoadingLambda      lambda) const -> Neon::set::Container;

    template <Neon::Execution execution = Neon::Execution::device,
              typename LoadingLambda = void*>
    auto newBetaContainer(const std::string& name,
                          LoadingLambda      lambda) const -> Neon::set::Container;

    template <Neon::Execution execution = Neon::Execution::device,
              typename LoadingLambdaAlpha = void*,
              typename LoadingLambdaBeta = void*>
    auto newAlphaBetaContainer(const std::string& name,
                               LoadingLambdaAlpha lambdaAlpha,
                               LoadingLambdaBeta  lambdaBeta) const -> Neon::set::Container;

    /**
     * Defines a new set of parameter to launch a Container
     */
    auto getLaunchParameters(Neon::DataView        dataView,
                             const Neon::index_3d& blockSize,
                             const size_t&         sharedMem) const -> Neon::set::LaunchParameters;

    /**
     * Retrieve the span associated to the grid w.r.t. some user defined parameters.
     */
    auto getSpan(Neon::Execution execution,
                 SetIdx          setIdx,
                 Neon::DataView  dataView) -> const Span&;

    /**
     * Retrieve the block vew grid internally used.
     * This grid can be leverage to allocate data at the block level.
     */
    auto getBlockViewGrid() const -> BlockView::Grid&;


    /**
     * Retrieve the block vew grid internally used.
     * This grid can be leverage to allocate data at the block level.
     */
    auto getActiveBitMask() const -> BlockView::Field<typename SBlock::BitMask, 1>&;

    /**
     * Helper function to retrieve the discrete index spacing used for the multi-resolution
     */
    template <int dummy = SBlock::isMultiResMode>
    auto helGetMultiResDiscreteIdxSpacing() const -> std::enable_if_t<dummy == 1, int>;


    /**
     * Help function to retrieve the block connectivity as a BlockViewGrid field
     */
    auto helpGetBlockConnectivity() const -> BlockView::Field<BlockIdx, 27>&;

    /**
     * Help function to retrieve the block origin as a BlockViewGrid field
     */
    auto helpGetDataBlockOriginField() const -> Neon::aGrid::Field<index_3d, 0>&;

    /**
     * Help function to retrieve the map that converts a stencil point id to 3d offset
     */
    auto helpGetStencilIdTo3dOffset() const -> Neon::set::MemSet<Neon::int8_3d>&;

    auto helpGetPartitioner1D() -> Neon::domain::tool::Partitioner1D&;

    /**
     * Help function retriev the device and the block index associated to a point in the BlockViewGrid grid
     */
    auto helpGetSetIdxAndGridIdx(Neon::index_3d idx) const -> std::tuple<Neon::SetIdx, Idx>;

    template <typename ActiveCellLambda>
    auto init_mask_field(ActiveCellLambda activeCellLambda) -> void;
    auto helpGetClassField() -> BlockView::Field<uint8_t, 1>&;


    struct Data
    {
        auto init(const Neon::Backend& bk)
        {
            spanTable.init(bk);
            launchParametersTable.init(bk);
        }

        Neon::domain::tool::SpanTable<Span> spanTable /** Span for each data view configurations */;
        Neon::set::LaunchParametersTable    launchParametersTable;

        Neon::domain::tool::Partitioner1D partitioner1D;
        Stencil                           stencil;
        Neon::sys::patterns::Engine       reduceEngine;

        Neon::aGrid                     memoryGrid /** memory allocator for fields */;
        Neon::aGrid::Field<index_3d, 0> mDataBlockOriginField;
        Neon::set::MemSet<int8_t>       mStencil3dTo1dOffset;

        BlockView::Grid                               blockViewGrid;
        BlockView::Field<typename SBlock::BitMask, 1> activeBitField;
        BlockView::Field<BlockIdx, 27>                blockConnectivity;
        Neon::set::MemSet<Neon::int8_3d>              stencilIdTo3dOffset;

        int mMultiResDiscreteIdxSpacing;

        // number of active voxels in each block
        Neon::set::DataSet<uint64_t> mNumActiveVoxel;


        // Stencil neighbor indices
        Neon::set::MemSet<NghIdx> mStencilNghIndex;

        AlphaGrid alphaGrid;
        BetaGrid  betaGrid;

        BlockView::Field<uint8_t, 1> maskClassBlockField;
        bool                         classFilterEnable;
    };
    std::shared_ptr<Data> mData;
};

constexpr int defaultBlockSize = 4;
using BlockDefault = StaticBlock<defaultBlockSize, defaultBlockSize, defaultBlockSize>;
extern template class bGridBlockMask<BlockDefault>;
}  // namespace Neon::domain::details::disaggregated::bGridBlockMask

#include "bGridBlockMask_imp.h"
#include "bMaskField_imp.h"
